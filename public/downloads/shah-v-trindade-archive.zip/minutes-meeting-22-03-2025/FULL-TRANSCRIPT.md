# Minutes of Meeting - 22.03.2025

**Case:** Mr. Vikram Shah v. Mrs. Riva Trindade & Ors.  
**Forum:** Hon'ble Sole Arbitrator, Mr. Nitin N. Sardesai, Senior Advocate  
**Document:** Minutes of Meeting - 22.03.2025  
**Kind:** order  
**Pages:** 2  
**Source file:** Minutes/Minutes of Meeting - 22.03.2025.pdf  
**SHA-256:** `bd5c6ecfd4b3d4bac6975b8645eb1527f63b70e797ce481db887b0e11183d3ce`

> This archive restates a party's papers under the Arbitration and Conciliation Act, 1996 and related Goa civil proceedings. It is not an award, not legal advice, and not a determination of fact.


## Contents

| No. | Section | PDF pages |
| --- | --- | --- |
| 1 | Minutes of Meeting - 22.03.2025 | 1-2 |

<!-- SECTION: full | PDF pages 1-2 -->

## Page 1 of 2

L
BEFORE THE SOLE ARBITRATOR
SR. ADV. NITIN N. N. P. SARDESSAI
AT PANAJI - GOA
VIKRAM SHAH
...CLAIMANT
VERSUS
RIVA TRINDADE AND 3 ORS
...RESPONDENTS
MINUTES OF PROCEEDINGS DATED 22.03.2025 at
04.00 PM
1. Adv. Noorani appeared on behalf of the Claimant, Adv.
Vledson Braganza with Adv. V. Pavithran appeared on behalf
of Respondents No. 1, 2 & 3, Respondent No. 4 Shri.
Murlidhara Sadarangani appeared in person. Mr. Riva
Trindade present in person.
2.
Mr. Vledson Braganza has filed the present application dated
22.03.2025 praying for directing the Claimant to furnish
documents to Respondents 1 to 3, copies of the said
application dated 22.03.2025 are furnished to the other side.
Adv. Braganza also submitted that the documents will be
relevant to decide the application u/s. 17 filed by the
Claimant.
15

---

## Page 2 of 2

19
ER
3.
4.
5.
6.
7.
Adv. Noorani states that he will file a reply to the same. Adv
Braganza states that he will argue the same along with S. 17
Application of the Claimant.
Reply if any to the application to be filed on or before next
date of hearing, advance copies to be served on other sides.
Mr. Sadarangani filed additional reply with new documents,
same taken on record.
With concurrence of all parties the matter is adjourned to
05th April 2025 at 06.00 PM at the same venue for arguments
on Claimants application u/s. 17 and application for
documents u/s.17.
Stand over to 05.04.2025 at 06.00 PM at the same venue.
Place: Panaji - Goa. Sr. Adv. Nitin N. N. P. Sardessai
Date:22.03.2025
Sole Arbitrator

---
