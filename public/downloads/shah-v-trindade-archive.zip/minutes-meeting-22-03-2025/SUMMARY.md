# Editorial summary — Minutes of Meeting - 22.03.2025

**Case:** Mr. Vikram Shah v. Mrs. Riva Trindade & Ors.  
**Forum:** Hon'ble Sole Arbitrator, Mr. Nitin N. Sardesai, Senior Advocate  
**Document:** Minutes of Meeting - 22.03.2025  
**Kind:** order  
**Pages:** 2

> Editorial only. This archive restates a party's papers under the Arbitration and Conciliation Act, 1996 and related Goa civil proceedings. It is not an award, not legal advice, and not a determination of fact. Figures below are as stated by the author of the paper, not as found by this archive.

## What this compilation is

1. A paper from the folder **Minutes**.
2. Classified here as **order** from the filename and opening pages.
3. Transcribed for reading; the original scan remains the source image.

## Parties / procedural posture

As named on the paper: Mr. Vikram Shah v. Mrs. Riva Trindade & Ors.. This document is one leaf in that compilation. It is not an award.

## Core money trail or operative facts

Tables and amounts, where they appear, are copied in the transcript. They are not restated as findings here.

## Annexure / document map

| Pages | Mark | Contents |
| --- | --- | --- |
| 1-2 | — | Minutes of Meeting - 22.03.2025 |

## Requested reading / prayers

If the paper contains prayers or a requested order, they remain in the transcript. This summary does not add any.

## Opening extract (as transcribed)

## Page 1 of 2

L
BEFORE THE SOLE ARBITRATOR
SR. ADV. NITIN N. N. P. SARDESSAI
AT PANAJI - GOA
VIKRAM SHAH
...CLAIMANT
VERSUS
RIVA TRINDADE AND 3 ORS
...RESPONDENTS
MINUTES OF PROCEEDINGS DATED 22.03.2025 at
04.00 PM
1. Adv. Noorani appeared on behalf of the Claimant, Adv.
Vledson Braganza with Adv. V. Pavithran appeared on behalf
of Respondents No. 1, 2 & 3, Respondent No. 4 Shri.
Murlidhara Sadarangani appeared in person. Mr. Riva
Trindade present in person.
2.
Mr. Vledson Braganza has filed the present application dated
22.03.2025 praying for directing the Claimant to furnish
documents to Respondents 1 to 3, copies of the said
application dated 22.03.2025 are furnished to the other side.
Adv. Braganza also submitted that the documents will be
relevant to decide the application u/s. 17 filed by the
Claimant.
15

---

## Page 2 of 2

19
ER
3.
4.
5.
6.
7.
Adv. Noorani states that he will file a reply to the same. Adv
