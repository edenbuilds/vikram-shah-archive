# 12.06.26 Application Seeking Leave to File Additional Reply (Respondents 1-3)

**Document:** 12.06.26 Application Seeking Leave to File Additional Reply (Respondents 1-3)  
**Mark:** —  
**PDF pages:** 1-13

> This archive restates a party's papers under the Arbitration and Conciliation Act, 1996 and related Goa civil proceedings. It is not an award, not legal advice, and not a determination of fact.

## Page 1 of 13

BEFORE THE ARBITRAL TRIBUNAL COMPRISING OF
THE SOLE ARBITRATOR SENIOR ADVOCATE N.N.P.
SARDESAI AT PANAJI, GOA
In the matter of:
VIKRAM SHAH
V/s.
RIVA TRINDADE & 3 Ors.
...Claimant
...Respondents
1
APPLICATION SEEKING LEAVE
TO FILE ADDITIONAL REPLY.
MAY IT PLEASE THIS HON'BLE TRIBUNAL:
The Respondent Nos. 1, 2 and 3 state and submit as under:
1. Vide Order dated 07.08.2024, passed in Application for
Appointment of Arbitrator No. 13/2024, this Arbitral
Tribunal was appointed to decide the dispute between the
parties arising out of the Agreement styled as the Articles of
Association, purportedly entered into between Mr. Pascoal
Trindade, the Claimant, and Respondent No. 4 herein.

---

## Page 2 of 13

[ILLEGIBLE]

---

## Page 3 of 13

2
2. Pursuant to the Order dated 07.08.2024, passed in
Application for Appointment of Arbitrator No. 13/2024 and
upon the constitution of the present Arbitral Tribunal, the
Claimant herein filed his Statement of Claim seeking reliefs
more particularly stated at the prayer clause therein.
3. The Respondents have filed their Statement of Defense in
the present arbitral proceedings and have been contesting the
claims raised by the Claimant. The Claimant herein had filed
an application seeking interim measures and reliefs from this
Tribunal, which has been objected to and disputed by these
Respondents by filing a detailed reply.
4. In the interregnum, these Respondent have obtained copies
of statement of accounts and deposition/Affidavit in
Evidence filed by the Claimant before the Court of Civil
Judge Senior Division at Panaji and other material which
were clearly suppressed by the Claimant. These
Respondents have already taken out an application
to produce the said documents on record before this

---

## Page 4 of 13

[ILLEGIBLE]

---

## Page 5 of 13

3
Tribunal. Similarly, these Respondents have also moved an
application seeking amendment of Statement of Claim in
order make appropriate averments qua the same amongst the
others.
5. Against such backdrop, the present Application is being
filed seeking leave of this Hon'ble Tribunal to file an
additional reply to the application seeking interim measures
and to bring on record the facts, pleadings and documents
which were suppressed from this Tribunal by the Claimant
and have become necessary for the proper, complete, and
effective adjudication of the disputes arising in the present
proceedings.
6. The Respondents submit that the additional reply is
primarily intended to bring on records facts which were
intentionally suppressed by the Claimant and further to
elaborate, clarify, and particularize the existing defences
concerning the legal effect of the Articles of Association, the
nature and extent of the rights asserted by the Claimant, the

---

## Page 6 of 13

[ILLEGIBLE]

---

## Page 7 of 13

4
status and rights of Respondent No. 2 as a moiety holder, the
effect of the Joint Venture Agreement dated 25.04.2014, and
the maintainability of the claims raised in the present
proceedings.
7. The Respondents further submit that certain facts and
documents relevant to the adjudication of the present dispute
have come to their knowledge and possession subsequent to
the filing of the Statement of Defense. In particular, the
Respondents have recently obtained banking records and
statements which disclose material transactions having a
direct bearing on the claims raised by the Claimant and the
reliefs sought in the present proceedings. The Respondents
seek to also place on record the Affidavit in Evidence filed
by the Claimant before the Civil Court, which the Claimant
had suppressed from this Tribunal wherein the Claimant
admitted that the subject properties belonged to these
Respondents.

---

## Page 8 of 13

[ILLEGIBLE]

---

## Page 9 of 13

5
8. The Respondents seek to place the said facts on record by
way of additional reply. The documents, averments and
material sought to be relied upon now have recently come in
possession of the Respondents after the last date of hearing.
9. The Respondents accordingly seek leave to file additional
reply annexed hereto and marked as ANNEXURE A.
10. The Respondents submit that the necessity to file additional
reply has arisen owing to suppression of material and false
statements made by the Claimant and same is necessary for
determining the real questions in controversy between
the parties and for enabling this Hon'ble Tribunal to
adjudicate the disputes in a comprehensive and effective
manner including application under Section 17 filed by the
Claimant.
11. It is a settled position that arbitral tribunals are empowered
to permit alteration, amendment and filing of additional
replies and/or statement to ensure complete and effective

---

## Page 10 of 13

[ILLEGIBLE]

---

## Page 11 of 13

6
adjudication of disputes and to avoid multiplicity of
proceedings.
12. No prejudice whatsoever shall be caused to the Claimant if
the additional reply is permitted to be taken on record. In the
event the present Application is allowed, the Claimant shall
have full opportunity to file such additional pleadings and
material as may be considered necessary in response thereto.
13. On the contrary, refusal of present application would result
in material facts and issues having a direct bearing on the
adjudication of the present dispute being excluded from
consideration, thereby causing serious prejudice to the
Respondents.
14. The balance of convenience is overwhelmingly in favour of
permitting the present application.
15. That this Hon'ble Tribunal has the necessary and requisite
jurisdiction to entertain and adjudicate the present

---

## Page 12 of 13

[ILLEGIBLE]

---

## Page 13 of 13

7
application. The facts sought to be incorporated are integral
to the subject-matter of the dispute and as such, fall well
within the scope of its jurisdiction and authority
Therefore, in the light of the above, the Respondents most
respectfully pray that this Hon'ble Tribunal be pleased to allow the
present application and permit the Respondents file additional
reply annexed hereto and marked as ANNEXURE A.
Date: 12.06.2026
Place: Panaji, Goa
Respondent No. 1
Respondent No. 2
Respondent No. 3

---
