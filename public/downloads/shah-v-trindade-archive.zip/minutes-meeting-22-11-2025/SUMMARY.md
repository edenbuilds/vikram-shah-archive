# Editorial summary — Minutes of Meeting - 22.11.2025

**Case:** Mr. Vikram Shah v. Mrs. Riva Trindade & Ors.  
**Forum:** Hon'ble Sole Arbitrator, Mr. Nitin N. Sardesai, Senior Advocate  
**Document:** Minutes of Meeting - 22.11.2025  
**Kind:** order  
**Pages:** 2

> Editorial only. This archive restates a party's papers under the Arbitration and Conciliation Act, 1996 and related Goa civil proceedings. It is not an award, not legal advice, and not a determination of fact. Figures below are as stated by the author of the paper, not as found by this archive.

## What this compilation is

1. A paper from the folder **Minutes**.
2. Classified here as **order** from the filename and opening pages.
3. Transcribed for reading; the original scan remains the source image.

## Parties / procedural posture

As named on the paper: Mr. Vikram Shah v. Mrs. Riva Trindade & Ors.. This document is one leaf in that compilation. It is not an award.

## Core money trail or operative facts

Tables and amounts, where they appear, are copied in the transcript. They are not restated as findings here.

## Annexure / document map

| Pages | Mark | Contents |
| --- | --- | --- |
| 1-2 | — | Minutes of Meeting - 22.11.2025 |

## Requested reading / prayers

If the paper contains prayers or a requested order, they remain in the transcript. This summary does not add any.

## Opening extract (as transcribed)

## Page 1 of 2

BEFORE THE SOLE ARBITRATOR

              SR. ADV. NITIN N. N. P. SARDESSAI

                       AT PANAJI – GOA

VIKRAM SHAH                                       …CLAIMANT

                              VERSUS

RIVA TRINDADE AND 3 ORS                           …RESPONDENTS


MINUTES OF PROCEEDINGS HELD ON 22nd NOVEMBER AT

                             11.30 AM

1.   Adv. Vledson Braganza appeared on behalf of Mr. Riva Trindade,

     Mrs. Albertina Trindade and Mrs. Karita Trindade. Respondent

     No. 1, 2 & 3. Respondent No. 4 Shri. Murlidhar Sadarangani

     present in person. Adv. Noorani sent an SMS informing there is

     some medical emergency in his family and as such will seek time.

     Adv. Noorani stated that he has informed to the contesting parties

     / their advocates these circumstances and that they have consented

     to an adjournment.



2.   The Tribunal inquired with Adv Braganza about the development

     in the settlement talks. Adv. Braganza informed that the talks are
