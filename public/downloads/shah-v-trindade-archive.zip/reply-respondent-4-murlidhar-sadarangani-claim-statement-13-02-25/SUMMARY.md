# Editorial summary — Reply of Respondent No 4 Murlidhar Sadarangani to Claim Statement dt 13.02.25

**Case:** Mr. Vikram Shah v. Mrs. Riva Trindade & Ors.  
**Forum:** Hon'ble Sole Arbitrator, Mr. Nitin N. Sardesai, Senior Advocate  
**Document:** Reply of Respondent No 4 Murlidhar Sadarangani to Claim Statement dt 13.02.25  
**Kind:** pleading  
**Pages:** 9

> Editorial only. This archive restates a party's papers under the Arbitration and Conciliation Act, 1996 and related Goa civil proceedings. It is not an award, not legal advice, and not a determination of fact. Figures below are as stated by the author of the paper, not as found by this archive.

## What this compilation is

1. A paper from the folder **SOC and SOD**.
2. Classified here as **pleading** from the filename and opening pages.
3. Transcribed for reading; the original scan remains the source image.

## Parties / procedural posture

As named on the paper: Mr. Vikram Shah v. Mrs. Riva Trindade & Ors.. This document is one leaf in that compilation. It is not an award.

## Core money trail or operative facts

Tables and amounts, where they appear, are copied in the transcript. They are not restated as findings here.

## Annexure / document map

| Pages | Mark | Contents |
| --- | --- | --- |
| 1-9 | — | Reply of Respondent No 4 Murlidhar Sadarangani to Claim Statement dt 13.02.25 |

## Requested reading / prayers

If the paper contains prayers or a requested order, they remain in the transcript. This summary does not add any.

## Opening extract (as transcribed)

## Page 1 of 9

J
7
1
-1-
اله Reply
Murli to
claim
BEFORE THE HON'BLE SOLE ARBITRATOR
MR. NITIN N. SARDESSAI, SR. ADVOCATE
AT PANAJI GOA
Statent
"
1
971
IN THE MATTER OF :-
Mr. Vikram Shah
son of late Chinubhai Manilal Shah,
aged 74 years, married,
businessman, Indian National,
resident of 28, Capri Building,
9, Manav Mandir Road,
Near Teen Batti Walkeshwar,
Malabar Hill, Mumbai - 400 006.
Maharashtra.
...Claimant
TANS

---

## Page 2 of 9

1.
Mr. Riva Trindade
Major of age, Resident of
Palbrika Mansion,
NIO Circle,
Dona Paula,
Tiswadi, Goa 403004;
